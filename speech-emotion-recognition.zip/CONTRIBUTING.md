# Contributing to Speech Emotion Recognition

We welcome contributions to this project. Please follow the guidelines below.

## Development Setup
1. Clone the repository.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Submitting Changes
1. Fork the repository.
2. Create a new branch for your feature/bugfix.
3. Commit your changes with a clear message.
4. Open a pull request.

## Code of Conduct
Please be respectful and follow our [Code of Conduct](CODE_OF_CONDUCT.md).
