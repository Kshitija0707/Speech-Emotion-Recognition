# model.py

def build_model():
    # TODO: Add code to build the LSTM model
    pass
